#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:matrix.glsl>
#moj_import <minecraft:globals.glsl>

uniform sampler2D Sampler0;
uniform sampler2D Sampler1;

in vec4 texProj0;
in float sphericalVertexDistance;
in float cylindricalVertexDistance;

const vec3[] COLORS = vec3[](
    vec3(0.200193, 0.023099, 0.003850),
    vec3(0.182167, 0.025223, 0.004671),
    vec3(0.206419, 0.033345, 0.006616),
    vec3(0.237940, 0.043927, 0.009152),
    vec3(0.258888, 0.053769, 0.011617),
    vec3(0.218836, 0.050501, 0.011222),
    vec3(0.286177, 0.072645, 0.016510),
    vec3(0.337997, 0.093599, 0.021666),
    vec3(0.340529, 0.102159, 0.024012),
    vec3(0.299632, 0.096804, 0.023049),
    vec3(0.358875, 0.124226, 0.029906),
    vec3(0.495685, 0.183022, 0.044485),
    vec3(0.434694, 0.170534, 0.041798),
    vec3(0.613457, 0.254821, 0.062919),
    vec3(0.843880, 0.370009, 0.091961),
    vec3(0.739480, 0.341299, 0.085325)
);

const mat4 SCALE_TRANSLATE = mat4(
    0.5, 0.0, 0.0, 0.25,
    0.0, 0.5, 0.0, 0.25,
    0.0, 0.0, 1.0, 0.0,
    0.0, 0.0, 0.0, 1.0
);

mat4 end_portal_layer(float layer) {
    mat4 translate = mat4(
        1.0, 0.0, 0.0, 17.0 / layer,
        0.0, 1.0, 0.0, (2.0 + layer / 1.5) * (GameTime * 1.5),
        0.0, 0.0, 1.0, 0.0,
        0.0, 0.0, 0.0, 1.0
    );

    mat2 rotate = mat2_rotate_z(radians((layer * layer * 4321.0 + layer * 9.0) * 2.0));

    mat2 scale = mat2((4.5 - layer / 4.0) * 2.0);

    return mat4(scale * rotate) * translate * SCALE_TRANSLATE;
}

out vec4 fragColor;

void main() {
    vec3 color = textureProj(Sampler0, texProj0).rgb * COLORS[0];
    for (int i = 0; i < PORTAL_LAYERS; i++) {
        color += textureProj(Sampler1, texProj0 * end_portal_layer(float(i + 1))).rgb * COLORS[i];
    }
    fragColor = apply_fog(vec4(color, 1.0), sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
