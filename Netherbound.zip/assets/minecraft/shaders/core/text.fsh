#version 330

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:globals.glsl>

uniform sampler2D Sampler0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in float sphericalVertexDistance;
in float cylindricalVertexDistance;
#endif

in vec4 vertexColor;
in vec2 texCoord0;

out vec4 fragColor;

void main() {
#ifdef IS_GRAYSCALE
    vec4 texColor = texture(Sampler0, texCoord0).rrrr;
#else
    vec4 texColor = texture(Sampler0, texCoord0);
#endif

#ifdef IS_SEE_THROUGH
    vec4 color = texColor * vertexColor;
#else
    vec4 color = texColor * vertexColor * ColorModulator;
#endif

// Netherbound alert glyph: text opacity 253 marks it. The shadow (rgb x0.25) keeps its own dark colour.
if (abs(vertexColor.a - 253.0 / 255.0) < 0.003 && max(vertexColor.r, max(vertexColor.g, vertexColor.b)) > 0.45) {
    float t = GameTime * 1200.0;
    float pulse = 0.5 + 0.5 * sin(t * 14.0);
    float scan = 0.5 + 0.5 * sin(gl_FragCoord.y * 0.18 + t * 22.0);
    vec3 hot = mix(vec3(1.0, 0.1, 0.03), vec3(1.0, 0.8, 0.25), clamp(pulse * 0.7 + scan * 0.3, 0.0, 1.0));
    color = vec4(hot, color.a / (253.0 / 255.0));
}
    if (color.a < 0.1) {
        discard;
    }

#ifdef IS_SEE_THROUGH
    fragColor = color * ColorModulator;
#elif defined(IS_GUI)
    fragColor = color;
#else
    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
#endif
}
