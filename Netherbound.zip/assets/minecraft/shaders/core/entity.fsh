#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

#moj_import <minecraft:globals.glsl>

vec3 nb_fire(float h) {
    vec3 c = mix(vec3(0.25, 0.0, 0.0), vec3(1.0, 0.4, 0.03), smoothstep(0.0, 0.55, h));
    return mix(c, vec3(1.0, 0.95, 0.7), smoothstep(0.55, 1.0, h));
}

float nb_hash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

vec2 nb_hash2(vec2 p) {
    return fract(sin(vec2(dot(p, vec2(127.1, 311.7)), dot(p, vec2(269.5, 183.3)))) * 43758.5453);
}

// Distance to the nearest cell border of a voronoi pattern (0 on a crack).
float nb_cracks(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    float d1 = 8.0;
    float d2 = 8.0;
    for (int y = -1; y <= 1; y++) {
        for (int x = -1; x <= 1; x++) {
            vec2 g = vec2(float(x), float(y));
            vec2 o = nb_hash2(i + g);
            float d = length(g + o - f);
            if (d < d1) {
                d2 = d1;
                d1 = d;
            } else if (d < d2) {
                d2 = d;
            }
        }
    }
    return d2 - d1;
}

// Hexagonal cell: xy = offset from the cell centre, z = distance to the cell border, w = a per-cell random id.
vec4 nb_hexcell(vec2 uv) {
    vec2 r = vec2(1.0, 1.7320508);
    vec2 h = r * 0.5;
    vec2 a = mod(uv, r) - h;
    vec2 b = mod(uv - h, r) - h;
    vec2 gv = dot(a, a) < dot(b, b) ? a : b;
    vec2 id = uv - gv;
    vec2 q = abs(gv);
    float e = 0.5 - max(dot(q, vec2(0.5, 0.8660254)), q.x);
    return vec4(gv, e, nb_hash(id));
}

// Netherbound VFX: m.r / m.g are the data map (see tools/vfx.py), id is the marker alpha (246-254).
vec4 nb_vfx(int id, vec3 m) {
    float t = GameTime * 1200.0;
    float d = m.r;
    float a = m.g * 6.2831853;
    if (id == 248) {
        // lightning bolt: m.b is the signed position across the strip, m.g the height. A jagged line re-rolls 14 times a second,
        // with a fork branching off halfway; white-hot core, orange glow
        float u = (m.b - 0.5) * 2.0;
        float h = m.g;
        float seed = floor(t * 14.0) * 1.7;
        float c = 0.45 * (0.5 * sin(h * 23.0 + seed) + 0.3 * sin(h * 57.0 + seed * 2.3) + 0.2 * sin(h * 113.0 + seed * 3.7)) * (1.0 - 0.3 * h);
        float c2 = c + (h - 0.55) * 0.9 + 0.12 * sin(h * 71.0 + seed);
        float dist = abs(u - c);
        float dist2 = h > 0.55 ? abs(u - c2) : 9.0;
        float core = exp(-dist * 34.0) + 0.6 * exp(-dist2 * 40.0);
        float glow = 0.4 * exp(-dist * 7.0) + 0.2 * exp(-dist2 * 9.0);
        float flick = 0.65 + 0.35 * step(0.35, nb_hash(vec2(floor(t * 28.0), 3.0)));
        float inten = clamp((core + glow) * flick, 0.0, 1.0);
        vec3 col = mix(vec3(1.0, 0.35, 0.05), vec3(1.0, 0.97, 0.88), clamp(core, 0.0, 1.0));
        return vec4(col, clamp(inten * 1.15, 0.0, 1.0));
    }
    if (id == 247) {
        // shield wall: hexagon grid with cells that flare at random, a scan band climbing the wall, bright rim at top and bottom
        vec4 hc = nb_hexcell(vec2(m.r * 5.0, m.g * 8.66));
        float lines = 1.0 - smoothstep(0.02, 0.09, hc.z);
        float flare = pow(0.5 + 0.5 * sin(t * (1.5 + hc.w * 3.0) + hc.w * 40.0), 6.0);
        float band = 1.0 - smoothstep(0.0, 0.08, 0.5 - abs(fract(m.g - t * 0.3) - 0.5));
        float edge = 1.0 - smoothstep(0.0, 0.07, min(m.g, 1.0 - m.g));
        float vert = smoothstep(0.0, 0.12, m.g) * (1.0 - smoothstep(0.82, 1.0, m.g));
        float hh = clamp(0.12 + 0.55 * lines + 0.45 * flare * (1.0 - lines) + 0.5 * band + 0.6 * edge, 0.0, 1.0);
        return vec4(nb_fire(hh), clamp((0.1 + 0.75 * hh) * (0.35 + 0.65 * vert + edge), 0.0, 0.85));
    }
    if (id == 246) {
        // cracked scorch decal: charred ground with glowing lava seams that pulse, fading out toward the rim
        vec2 p = vec2(cos(a), sin(a)) * d * 5.0;
        float edgeDist = nb_cracks(p);
        float crack = 1.0 - smoothstep(0.0, 0.11, edgeDist);
        float pulse = 0.65 + 0.35 * sin(t * 3.0 + nb_hash(floor(p)) * 6.0);
        float rimFade = 1.0 - smoothstep(0.7, 1.0, d);
        float hh = clamp(crack * pulse * 1.1, 0.0, 1.0);
        vec3 col = mix(vec3(0.03, 0.0, 0.0), nb_fire(hh), clamp(crack * 1.4, 0.0, 1.0));
        return vec4(col, clamp(max(crack * 0.95, 0.55 * (1.0 - smoothstep(0.3, 1.0, d))) * rimFade * 1.2, 0.0, 0.95));
    }
    if (id == 254) {
        // telegraph disc: waves rolling outwards, spinning spokes, a hot rim, an urgent pulse
        float wave = smoothstep(0.55, 1.0, fract(d * 2.5 - t * 1.2));
        float spokes = pow(0.5 + 0.5 * sin(a * 12.0 + d * 8.0 - t * 3.0), 4.0);
        float rim = smoothstep(0.88, 0.95, d);
        float pulse = 0.7 + 0.3 * sin(t * 8.0);
        float h = clamp((0.25 + 0.45 * wave + 0.35 * spokes * (1.0 - 0.5 * d) + 0.7 * rim) * pulse, 0.0, 1.0);
        return vec4(nb_fire(h), clamp(0.3 + 0.7 * h, 0.0, 0.92));
    }
    if (id == 251) {
        // impact disc: bright ring, white-hot centre, sparks racing round the edge
        float ring = smoothstep(0.62, 0.85, d) * (1.0 - smoothstep(0.9, 1.0, d));
        float core = (1.0 - smoothstep(0.0, 0.6, d)) * 0.5;
        float spark = pow(0.5 + 0.5 * sin(a * 20.0 + t * 12.0), 8.0) * smoothstep(0.3, 0.9, d);
        float h = clamp(ring + core + spark * 0.8, 0.0, 1.0);
        return vec4(mix(vec3(1.0, 0.55, 0.15), vec3(1.0, 0.97, 0.85), h), clamp(h * 1.1, 0.0, 0.95));
    }
    if (id == 250) {
        // void disc: purple swirl with a bright edge
        float sw = 0.5 + 0.5 * sin(a * 4.0 - d * 14.0 + t * 4.0);
        float rim = smoothstep(0.85, 0.95, d);
        float h = clamp(0.25 + 0.5 * sw * (1.0 - d * 0.4) + rim, 0.0, 1.0);
        return vec4(mix(vec3(0.05, 0.0, 0.1), vec3(0.65, 0.15, 0.95), h), clamp(0.45 + 0.5 * h, 0.0, 0.95));
    }
    if (id == 253) {
        // plasma orb: two counter-rotating swirls, white-hot core, soft edge, restless flicker
        float s1 = 0.5 + 0.5 * sin(a * 3.0 + d * 12.0 - t * 7.0);
        float s2 = 0.5 + 0.5 * sin(a * 5.0 - d * 9.0 + t * 5.0);
        float plasma = clamp(s1 * 0.6 + s2 * 0.4, 0.0, 1.0);
        float core = 1.0 - smoothstep(0.0, 0.55, d);
        float flick = 0.9 + 0.1 * sin(t * 23.0);
        float h = clamp((plasma * 0.75 * (1.0 - d * 0.4) + core + 0.12) * flick, 0.0, 1.0);
        return vec4(nb_fire(h), 1.0 - smoothstep(0.78, 1.0, d));
    }
    if (id == 252) {
        // charge lane: m.r runs along the lane, m.g across; chevrons stream down it, bright edges
        float across = abs(m.g - 0.5) * 2.0;
        float ch = fract(m.r * 7.0 - t * 2.5 + across * 1.5);
        float chev = smoothstep(0.5, 0.62, ch) * (1.0 - smoothstep(0.82, 0.95, ch));
        float edge = smoothstep(0.8, 0.95, across);
        float pulse = 0.75 + 0.25 * sin(t * 9.0);
        float h = clamp((0.3 + 0.6 * chev + 0.7 * edge) * pulse, 0.0, 1.0);
        return vec4(nb_fire(h), clamp(0.35 + 0.6 * h, 0.0, 0.92));
    }
    // 249 light beam: m.r is the distance from the beam's axis, m.g the height; energy bands climb it
    float core = pow(1.0 - d, 1.6);
    float band = 0.5 + 0.5 * sin(m.g * 40.0 - t * 12.0);
    float h = clamp(core * (0.6 + 0.5 * band) + (1.0 - d) * 0.2, 0.0, 1.0);
    return vec4(mix(vec3(1.0, 0.7, 0.3), vec3(1.0, 1.0, 0.9), h), clamp(core * 0.95 + 0.05, 0.0, 0.95) * (1.0 - smoothstep(0.85, 1.0, m.g) * 0.6));
}

uniform sampler2D Sampler0;

#ifdef DISSOLVE
uniform sampler2D DissolveMaskSampler;
#endif

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
#ifdef PER_FACE_LIGHTING
in vec4 vertexPerFaceColorBack;
in vec4 vertexPerFaceColorFront;
#else
in vec4 vertexColor;
#endif

#ifndef EMISSIVE
in vec4 lightMapColor;
#endif

#ifndef NO_OVERLAY
in vec4 overlayColor;
#endif

in vec2 texCoord0;

out vec4 fragColor;

void main() {
    vec4 color = texture(Sampler0, texCoord0);

int nbMark = int(color.a * 255.0 + 0.5);
if (nbMark >= 246 && nbMark <= 254) {
    vec4 fx = nb_vfx(nbMark, color.rgb);
    if (fx.a < 0.04) {
        discard;
    }
    fragColor = apply_fog(fx, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
    return;
}
#ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
#endif

#ifdef PER_FACE_LIGHTING
    vec4 faceVertexColor = gl_FrontFacing ? vertexPerFaceColorFront : vertexPerFaceColorBack;
#else
    vec4 faceVertexColor = vertexColor;
#endif

#ifdef DISSOLVE
    if (faceVertexColor.a < texture(DissolveMaskSampler, texCoord0).a) {
        discard;
    }
    // The dissolve effect entirely replaces translucency
    faceVertexColor.a = 1.0;
#endif

    color *= faceVertexColor * ColorModulator;
#ifndef NO_OVERLAY
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
#endif
#ifndef EMISSIVE
    color *= lightMapColor;
#endif

    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
