#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

#moj_import <minecraft:globals.glsl>

flat in vec4 nbTint;
flat in ivec2 nbLight;
in vec3 nbWorld;

// ---------------------------------------------------------------- Netherbound VFX helpers

float nbHash(vec2 p) {
    p = fract(p * vec2(123.34, 456.21));
    p += dot(p, p + 45.32);
    return fract(p.x * p.y);
}

float nbNoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    float a = nbHash(i);
    float b = nbHash(i + vec2(1.0, 0.0));
    float c = nbHash(i + vec2(0.0, 1.0));
    float d = nbHash(i + vec2(1.0, 1.0));
    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

float nbFbm(vec2 p) {
    float v = 0.0;
    float amp = 0.5;
    for (int i = 0; i < 4; i++) {
        v += amp * nbNoise(p);
        p = p * 2.03 + vec2(17.1, 9.2);
        amp *= 0.5;
    }
    return v;
}

// 4x4 ordered dither threshold in [0, 1) for an integer pixel.
float nbBayer(vec2 cell) {
    ivec2 c = ivec2(mod(cell, 4.0));
    int i = c.x + c.y * 4;
    int m[16] = int[16](0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5);
    return (float(m[i]) + 0.5) / 16.0;
}

// Distance to the nearest voronoi edge (0 on a crack).
float nbCracks(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    float d1 = 8.0;
    float d2 = 8.0;
    for (int y = -1; y <= 1; y++) {
        for (int x = -1; x <= 1; x++) {
            vec2 g = vec2(float(x), float(y));
            vec2 o = vec2(nbHash(i + g), nbHash(i + g + 31.7));
            float d = length(g + o - f);
            if (d < d1) {
                d2 = d1;
                d1 = d;
            } else if (d < d2) {
                d2 = d;
            }
        }
    }
    return d2 - d1;
}

// Palettes: index 1 (dim) .. 5 (hottest); index 0 is never drawn.
vec3 nbFire(int i) {
    if (i <= 1) return vec3(0.43, 0.07, 0.03);
    if (i == 2) return vec3(0.78, 0.22, 0.05);
    if (i == 3) return vec3(0.96, 0.50, 0.09);
    if (i == 4) return vec3(1.00, 0.79, 0.24);
    return vec3(1.00, 0.97, 0.72);
}

vec3 nbHoly(int i) {
    if (i <= 1) return vec3(0.62, 0.27, 0.06);
    if (i == 2) return vec3(0.94, 0.56, 0.16);
    if (i == 3) return vec3(1.00, 0.80, 0.38);
    if (i == 4) return vec3(1.00, 0.93, 0.70);
    return vec3(1.00, 1.00, 0.95);
}

vec3 nbVoid(int i) {
    if (i <= 1) return vec3(0.09, 0.02, 0.14);
    if (i == 2) return vec3(0.27, 0.06, 0.42);
    if (i == 3) return vec3(0.52, 0.17, 0.78);
    if (i == 4) return vec3(0.78, 0.48, 1.00);
    return vec3(0.96, 0.86, 1.00);
}

// Heat (0-1) to a palette level with ordered dithering, 0 = nothing.
int nbLevel(float heat, vec2 cell) {
    float h = clamp(heat, 0.0, 1.0) * 5.0 + (nbBayer(cell) - 0.5) * 0.85;
    return int(clamp(floor(h + 0.5), 0.0, 5.0));
}

float nbAlpha(int lvl) {
    if (lvl <= 1) return 0.55;
    if (lvl == 2) return 0.78;
    if (lvl == 3) return 0.9;
    return 1.0;
}

vec4 nbPaint(int pal, int lvl) {
    vec3 c = pal == 1 ? nbHoly(lvl) : pal == 2 ? nbVoid(lvl) : nbFire(lvl);
    return vec4(c, nbAlpha(lvl));
}

// ---------------------------------------------------------------- the effects
// uv: 0-1 across the quad (y = 0 at the top), size: blocks across (height for upright quads, length for the lane),
// param: the 9-bit display parameter, age: ticks alive, prog: age / lifetime (0 when looping)
// Shapes are pixel art (16 px per block, palette + ordered dither); glows are smooth, low-alpha halos around them.

vec4 nbGlow(vec3 col, float a) {
    return vec4(col, clamp(a, 0.0, 0.6));
}

vec4 nbEffect(int id, vec2 uv, float size, float param, float age, float prog) {
    float sec = age / 20.0;
    size = max(size, 1.0);
    // the quad's size in blocks; strips have a fixed width (the shield passes its own)
    vec2 dims = id == 4 ? vec2(3.4, size) : id == 5 ? vec2(2.5, size) : id == 6 ? vec2(8.0, size)
            : id == 7 ? vec2(max(param, 1.0) / 10.0, size) : vec2(size);
    vec2 px = dims * 16.0;                           // 16 pixels per block, like the blocks around it
    vec2 cell = floor(uv * px);
    vec2 q = (cell + 0.5) / px;
    vec2 p = q * 2.0 - 1.0;
    float d = length(p);
    float ang = atan(p.y, p.x);
    float turn = ang / 6.2831853;

    if (id == 0) {
        // TELEGRAPH: a burning fill grows out to the rim as the hit approaches; energy ripples converge on the centre,
        // a dashed rim and a counter-rotating inner ring turn, a soft halo pulses around it, white flash at the end
        float R = 0.86;
        float dn = d / R;
        float pulse = 0.5 + 0.5 * sin(sec * (8.0 + 10.0 * prog));
        if (dn > 1.0) {
            float h = 1.0 - (d - R) / (1.0 - R);
            if (h <= 0.0) return vec4(0.0);
            return nbGlow(prog > 0.93 ? vec3(1.0, 0.9, 0.6) : vec3(1.0, 0.35, 0.05), h * h * (0.18 + 0.22 * pulse + 0.3 * prog));
        }
        float fill = prog * prog * (3.0 - 2.0 * prog);
        float front = fill + 0.035 * (nbNoise(vec2(turn * 40.0, sec * 6.0)) - 0.5);
        float heat;
        if (dn > 0.93) {
            float dash = step(0.4, fract(turn * max(10.0, floor(size * 2.0)) - sec * 0.8));
            heat = dash > 0.5 ? 0.9 : 0.55;
        } else if (dn > 0.79 && dn < 0.82) {
            heat = step(0.5, fract(turn * max(16.0, floor(size * 3.0)) + sec * 1.2)) * 0.7;
        } else if (dn < front) {
            float flow = nbFbm(p * size * 0.3 + vec2(sec * 0.6, -sec * 1.0));
            float veins = 1.0 - smoothstep(0.0, 0.12, abs(nbFbm(p * size * 0.18 - sec * 0.3) - 0.5));
            heat = 0.4 + 0.42 * flow + 0.25 * veins;
            if (front - dn < 0.045) heat = 1.0;                          // the advancing front
        } else {
            float ripple = fract(dn * 5.0 + sec * 1.6);
            heat = 0.16 + 0.05 * pulse + (ripple < 0.12 ? 0.18 : 0.0) + 0.06 * nbNoise(p * size * 0.6);
        }
        if (prog > 0.93) heat = 1.0;
        int lvl = nbLevel(heat, cell);
        if (lvl == 0) return vec4(0.0);
        return nbPaint(0, lvl);
    }
    if (id == 1) {
        // SHOCK: a ragged ring racing outward with a soft glow on both sides, embers and a heat haze left behind it
        float t = 1.0 - (1.0 - prog) * (1.0 - prog);
        float r = t * 0.9 * (0.96 + 0.04 * nbNoise(vec2(turn * 30.0, sec * 4.0)));
        float w = mix(0.07, 0.02, prog);
        float off = abs(d - r);
        float fade = 1.0 - prog * 0.7;
        if (off < w) {
            int lvl = nbLevel((1.0 - off / w * 0.6) * fade + 0.1, cell);
            if (lvl > 0) return nbPaint(1, lvl);
        }
        if (d < r && nbHash(cell + floor(sec * 12.0)) > 0.982) return nbPaint(1, nbLevel(0.7 * (1.0 - prog) + 0.2, cell));
        float g = exp(-off / (w * 2.5)) * fade;
        if (d < r) g = max(g, 0.18 * (1.0 - prog) * (1.0 - d / max(r, 0.01)));
        if (g < 0.03) return vec4(0.0);
        return nbGlow(vec3(1.0, 0.7, 0.3), g * 0.55);
    }
    if (id == 2) {
        // VOID: spiral arms pulled into a black centre, sparks sucked inward, a bright purple rim and halo
        float R = 0.85;
        float grow = clamp(prog / 0.18, 0.0, 1.0) * R;
        float fade = 1.0 - smoothstep(0.8, 1.0, prog);
        if (d > grow) {
            float h = 1.0 - (d - grow) / (1.0 - R + 0.001);
            if (h <= 0.0) return vec4(0.0);
            return nbGlow(vec3(0.6, 0.2, 1.0), h * h * 0.45 * fade);
        }
        float dn = d / R;
        float sector = floor(turn * 28.0);
        float phase = fract(nbHash(vec2(sector, 9.0)) + sec * 0.9);
        float star = abs(dn - (1.0 - phase)) < 0.03 && abs(fract(turn * 28.0) - 0.5) < 0.18 ? 1.0 : 0.0;
        float arms = 0.5 + 0.5 * sin(ang * 3.0 + log(max(dn, 0.02)) * 7.0 + sec * 5.0);
        float heat = arms * (0.2 + 0.6 * dn) + 0.12 * nbNoise(p * size + sec) + star * 0.8;
        if (d > grow - 0.05) heat = 0.95;
        if (dn < 0.16) heat = 0.06;
        int lvl = nbLevel(heat * fade, cell);
        if (lvl == 0) return vec4(0.0);
        return nbPaint(2, lvl);
    }
    if (id == 3) {
        // ORB: a white-hot core, flame tongues swirling outward, embers circling, a soft glow around it
        float n = nbFbm(vec2(turn * 9.0 + sec * 0.6, d * 3.0 - sec * 3.0)) - 0.5;
        float tongues = 0.5 + 0.5 * sin(ang * 7.0 + sec * 5.0 + d * 6.0);
        float heat = 1.35 - d * 1.75 + n * 0.85 + tongues * 0.18 + 0.06 * sin(sec * 23.0);
        float sector = floor(turn * 10.0 + sec * 0.7);
        float er = 0.72 + 0.12 * sin(sec * 3.0 + sector);
        bool ember = abs(d - er) < 0.035 && abs(fract(turn * 10.0 + sec * 0.7) - 0.5) < 0.12 && nbHash(vec2(sector, 4.0)) > 0.3;
        if (ember) heat = max(heat, 0.8);
        int lvl = nbLevel(heat, cell);
        if (lvl > 0) return nbPaint(0, lvl);
        float g = 1.0 - smoothstep(0.35, 1.0, d);
        if (g < 0.02) return vec4(0.0);
        return nbGlow(vec3(1.0, 0.45, 0.08), g * g * 0.5);
    }
    if (id == 4) {
        // LANE: x across, y along (0 = start). A burning fill races along with chevrons inside, hazard edges outside it
        float across = abs(q.x * 2.0 - 1.0);
        float along = 1.0 - q.y;
        float fill = prog * prog * (3.0 - 2.0 * prog);
        float heat;
        if (across > 0.86) {
            heat = fract(along * size * 0.5 - sec * 2.0) < 0.5 ? 0.9 : 0.55;
        } else if (along < fill) {
            float ch = fract(along * size * 0.35 - across * 0.6 - sec * 2.2);
            heat = ch < 0.3 ? 0.95 : 0.38 + 0.45 * nbFbm(vec2(across * 3.0, along * size * 0.4 - sec * 2.0));
            if (fill - along < 0.03) heat = 1.0;
        } else {
            float ch = fract(along * size * 0.35 - across * 0.6 - sec * 1.0);
            heat = ch < 0.12 ? 0.32 : 0.15;
        }
        int lvl = nbLevel(heat, cell);
        if (lvl == 0) return vec4(0.0);
        return nbPaint(0, lvl);
    }
    if (id == 5) {
        // BEAM: a pillar of light, hot core with bands racing up, a flare at its foot and a soft glow around it
        float x = q.x * 2.0 - 1.0;
        float y = 1.0 - q.y;
        float life = smoothstep(0.0, 0.06, prog) * (1.0 - smoothstep(0.55, 1.0, prog));
        float width = 0.45 * (0.85 + 0.15 * sin(sec * 30.0)) * (1.0 + 0.8 * (1.0 - smoothstep(0.0, 0.06, y)));
        float ax = abs(x) / width;
        float bands = fract(y * size * 0.25 - sec * 3.0) < 0.25 ? 0.25 : 0.0;
        float turb = nbFbm(vec2(x * 3.0, y * size * 0.3 - sec * 5.0)) - 0.5;
        float top = 1.0 - smoothstep(0.8, 1.0, y);
        if (ax < 1.0) {
            int lvl = nbLevel(((1.0 - ax) * 1.25 + bands + turb * 0.5) * life * top, cell);
            if (lvl > 0) return nbPaint(1, lvl);
        }
        float g = (1.0 - smoothstep(0.0, 1.0, abs(x))) * life * top;
        if (g < 0.02) return vec4(0.0);
        return nbGlow(vec3(1.0, 0.75, 0.35), g * 0.4);
    }
    if (id == 6) {
        // BOLT: a jagged, forking lightning stroke (straight segments, re-rolled ten times a second), white core, orange glow
        float y = 1.0 - q.y;
        float seed = floor(sec * 10.0);
        float segs = max(6.0, floor(dims.y * 0.9));
        float ys = y * segs;
        float i = floor(ys);
        float f = fract(ys);
        float x0 = i < 0.5 ? 0.0 : (nbHash(vec2(i, seed)) - 0.5) * 0.55;
        float x1 = (nbHash(vec2(i + 1.0, seed)) - 0.5) * 0.55;
        float y4 = y * segs * 4.0;
        float j0 = (nbHash(vec2(floor(y4), seed + 3.0)) - 0.5) * 0.08;
        float j1 = (nbHash(vec2(floor(y4) + 1.0, seed + 3.0)) - 0.5) * 0.08;
        float cx = mix(x0, x1, f) + mix(j0, j1, fract(y4));
        float x = q.x * 2.0 - 1.0;
        float unit = 2.0 / px.x;                                      // one pixel in x
        float dist = abs(x - cx) / unit;
        // one fork leaving a random node and running down and out
        float k = floor(nbHash(vec2(seed, 5.0)) * segs * 0.5 + segs * 0.35);
        float yk = k / segs;
        float xk = (nbHash(vec2(k, seed)) - 0.5) * 0.55;
        float dir = nbHash(vec2(seed, 6.0)) > 0.5 ? 1.0 : -1.0;
        float fork = 99.0;
        if (y < yk && y > yk - 0.3) {
            float by = (yk - y) * segs;
            float bj = (nbHash(vec2(floor(by * 2.0), seed + 8.0)) - 0.5) * 0.12;
            fork = abs(x - (xk + (yk - y) * dir * 1.6 + bj)) / unit * (1.0 + (yk - y) * 3.0);
        }
        float m = min(dist, fork);
        float flick = nbHash(vec2(seed, 1.0)) > 0.2 ? 1.0 : 0.4;
        float life = (1.0 - smoothstep(0.55, 1.0, prog)) * flick;
        if (m < 1.0) return nbPaint(1, 5);
        if (m < 2.5) return nbPaint(1, 4);
        float g = exp(-m / 7.0) * life;
        if (g < 0.03) return vec4(0.0);
        return nbGlow(vec3(1.0, 0.55, 0.15), g * 0.75);
    }
    if (id == 7) {
        // SHIELD: a faint amber hexagon lattice that lets the boss show through; cells flare, a scan band climbs it
        vec2 hp = vec2(q.x * dims.x, (1.0 - q.y) * dims.y) * 0.6;           // hexes about 1.7 blocks wide
        vec2 r = vec2(1.0, 1.7320508);
        vec2 a = mod(hp, r) - r * 0.5;
        vec2 b = mod(hp - r * 0.5, r) - r * 0.5;
        vec2 gv = dot(a, a) < dot(b, b) ? a : b;
        vec2 cid = hp - gv;
        vec2 aq = abs(gv);
        float edge = 0.5 - max(dot(aq, vec2(0.5, 0.8660254)), aq.x);
        float y = 1.0 - q.y;
        float flare = step(0.9, fract(nbHash(cid) + sec * 0.35));
        float scan = abs(y - fract(sec * 0.3)) < 0.025 ? 1.0 : 0.0;
        float fadeLow = smoothstep(0.0, 0.2, y) * (1.0 - smoothstep(0.88, 1.0, y));
        // kept faint on purpose: the boss model has to stay readable through it
        if (edge < 0.035 || y > 0.985) {
            float lit = (0.5 + 0.35 * scan + 0.2 * flare) * mix(0.25, 1.0, fadeLow);
            if (nbBayer(cell) > 0.35 + 0.65 * lit) return vec4(0.0);        // dithered, so the lines break up
            vec4 c = nbPaint(0, max(2, nbLevel(lit, cell)));
            c.a = 0.45 * mix(0.4, 1.0, fadeLow);
            return c;
        }
        float g = (flare * 0.07 + scan * 0.14) * fadeLow;
        if (g < 0.03) return vec4(0.0);
        return nbGlow(vec3(1.0, 0.5, 0.1), g);
    }
    if (id == 8) {
        // SCORCH: charred ground split by glowing lava seams that pulse and cool down over its life, embers winking
        if (d > 1.0) return vec4(0.0);
        float edge = nbCracks(p * size * 0.22);
        float cool = 1.0 - prog;
        float pulse = 0.7 + 0.3 * sin(sec * 3.0 + nbHash(floor(p * size * 0.22)) * 6.0);
        float rimFade = 1.0 - smoothstep(0.5, 1.0, d + 0.15 * nbNoise(p * size * 0.3));
        if (rimFade <= nbBayer(cell)) return vec4(0.0);
        if (edge < 0.07 && cool > 0.05) {
            return nbPaint(0, max(2, nbLevel((0.75 + 0.3 * (1.0 - edge / 0.07)) * pulse * cool + 0.1, cell)));
        }
        if (nbHash(cell + floor(sec * 4.0)) > 0.993 && cool > 0.2) return nbPaint(0, 4);
        float glow = exp(-edge / 0.09) * cool * pulse;
        float soot = 0.05 + 0.05 * nbNoise(p * size);
        vec3 col = mix(vec3(soot, soot * 0.6, soot * 0.5), vec3(0.9, 0.25, 0.04), clamp(glow, 0.0, 1.0));
        return vec4(col, (0.8 * (1.0 - smoothstep(0.7, 1.0, prog))) * rimFade);
    }
    return vec4(0.0);
}

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec4 lightMapColor;
in vec4 overlayColor;
in vec2 texCoord0;

out vec4 fragColor;

void main() {
    vec4 color = texture(Sampler0, texCoord0);

    {
        ivec4 nbRaw = ivec4(round(color * 255.0));
        if (nbRaw.a == 250 && nbRaw.b >= 200 && nbRaw.b <= 215) {
            // coordinate map: read the exact texel at mip 0, then add the position inside it
            ivec2 nbSize = textureSize(Sampler0, 0);
            vec2 nbTexel = texCoord0 * vec2(nbSize);
            vec4 nbMap = texelFetch(Sampler0, ivec2(nbTexel), 0);
            vec2 nbUv = (round(nbMap.rg * 255.0) + fract(nbTexel)) / 256.0;
            ivec3 nbT = ivec3(round(nbTint.rgb * 255.0));
            float nbStart = float(nbT.r + ((nbT.g & 127) << 8));
            float nbDur = float(((nbT.g >> 7) << 8) + nbT.b);
            float nbSizeBlocks = float((nbLight.x >> 4) * 16 + (nbLight.y >> 4));
            float nbAge = mod(GameTime * 24000.0 - nbStart + 24000.0, 24000.0);
            float nbProg = nbDur > 0.0 ? clamp(nbAge / nbDur, 0.0, 1.0) : 0.0;
            vec4 nbFx = nbEffect(nbRaw.b - 200, nbUv, nbSizeBlocks, nbDur, nbAge, nbRaw.b == 207 ? 0.0 : nbProg);
            if (nbFx.a < 0.02) {
                discard;
            }
            fragColor = apply_fog(nbFx, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
            return;
        }
    }
#ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
#endif

    color *= vertexColor * ColorModulator;
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
    color *= lightMapColor;

    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
