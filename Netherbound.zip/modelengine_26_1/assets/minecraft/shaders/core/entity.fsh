#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

#moj_import <minecraft:globals.glsl>

vec3 nb_fire(float h) {
    vec3 c = mix(vec3(0.25, 0.0, 0.0), vec3(1.0, 0.4, 0.03), smoothstep(0.0, 0.55, h));
    return mix(c, vec3(1.0, 0.95, 0.7), smoothstep(0.55, 1.0, h));
}

// Netherbound VFX: m.r / m.g are the data map (see tools/vfx.py), id is the marker alpha (249-254).
vec4 nb_vfx(int id, vec3 m) {
    float t = GameTime * 1200.0;
    float d = m.r;
    float a = m.g * 6.2831853;
    if (id == 254) {
        // telegraph disc: waves rolling outwards, spinning spokes, a hot rim, an urgent pulse
        float wave = smoothstep(0.55, 1.0, fract(d * 2.5 - t * 1.2));
        float spokes = pow(0.5 + 0.5 * sin(a * 12.0 + d * 8.0 - t * 3.0), 4.0);
        float rim = smoothstep(0.88, 0.95, d);
        float pulse = 0.7 + 0.3 * sin(t * 8.0);
        float h = clamp((0.25 + 0.45 * wave + 0.35 * spokes * (1.0 - 0.5 * d) + 0.7 * rim) * pulse, 0.0, 1.0);
        return vec4(nb_fire(h), clamp(0.3 + 0.7 * h, 0.0, 0.92));
    }
    if (id == 251) {
        // impact disc: bright ring, white-hot centre, sparks racing round the edge
        float ring = smoothstep(0.62, 0.85, d) * (1.0 - smoothstep(0.9, 1.0, d));
        float core = (1.0 - smoothstep(0.0, 0.6, d)) * 0.5;
        float spark = pow(0.5 + 0.5 * sin(a * 20.0 + t * 12.0), 8.0) * smoothstep(0.3, 0.9, d);
        float h = clamp(ring + core + spark * 0.8, 0.0, 1.0);
        return vec4(mix(vec3(1.0, 0.55, 0.15), vec3(1.0, 0.97, 0.85), h), clamp(h * 1.1, 0.0, 0.95));
    }
    if (id == 250) {
        // void disc: purple swirl with a bright edge
        float sw = 0.5 + 0.5 * sin(a * 4.0 - d * 14.0 + t * 4.0);
        float rim = smoothstep(0.85, 0.95, d);
        float h = clamp(0.25 + 0.5 * sw * (1.0 - d * 0.4) + rim, 0.0, 1.0);
        return vec4(mix(vec3(0.05, 0.0, 0.1), vec3(0.65, 0.15, 0.95), h), clamp(0.45 + 0.5 * h, 0.0, 0.95));
    }
    if (id == 253) {
        // plasma orb: two counter-rotating swirls, white-hot core, soft edge, restless flicker
        float s1 = 0.5 + 0.5 * sin(a * 3.0 + d * 12.0 - t * 7.0);
        float s2 = 0.5 + 0.5 * sin(a * 5.0 - d * 9.0 + t * 5.0);
        float plasma = clamp(s1 * 0.6 + s2 * 0.4, 0.0, 1.0);
        float core = 1.0 - smoothstep(0.0, 0.55, d);
        float flick = 0.9 + 0.1 * sin(t * 23.0);
        float h = clamp((plasma * 0.75 * (1.0 - d * 0.4) + core + 0.12) * flick, 0.0, 1.0);
        return vec4(nb_fire(h), 1.0 - smoothstep(0.78, 1.0, d));
    }
    if (id == 252) {
        // charge lane: m.r runs along the lane, m.g across; chevrons stream down it, bright edges
        float across = abs(m.g - 0.5) * 2.0;
        float ch = fract(m.r * 7.0 - t * 2.5 + across * 1.5);
        float chev = smoothstep(0.5, 0.62, ch) * (1.0 - smoothstep(0.82, 0.95, ch));
        float edge = smoothstep(0.8, 0.95, across);
        float pulse = 0.75 + 0.25 * sin(t * 9.0);
        float h = clamp((0.3 + 0.6 * chev + 0.7 * edge) * pulse, 0.0, 1.0);
        return vec4(nb_fire(h), clamp(0.35 + 0.6 * h, 0.0, 0.92));
    }
    // 249 light beam: m.r is the distance from the beam's axis, m.g the height; energy bands climb it
    float core = pow(1.0 - d, 1.6);
    float band = 0.5 + 0.5 * sin(m.g * 40.0 - t * 12.0);
    float h = clamp(core * (0.6 + 0.5 * band) + (1.0 - d) * 0.2, 0.0, 1.0);
    return vec4(mix(vec3(1.0, 0.7, 0.3), vec3(1.0, 1.0, 0.9), h), clamp(core * 0.95 + 0.05, 0.0, 0.95) * (1.0 - smoothstep(0.85, 1.0, m.g) * 0.6));
}

uniform sampler2D Sampler0;

#if defined(ALPHA_CUTOUT) && !defined(EMISSIVE) && !defined(NO_OVERLAY) && !defined(APPLY_TEXTURE_MATRIX)
#define MAYBE_PLAYERDISP 1
#endif

#ifdef DISSOLVE
uniform sampler2D DissolveMaskSampler;
#endif

in float sphericalVertexDistance;
in float cylindricalVertexDistance;

#ifdef PER_FACE_LIGHTING
in vec4 vertexPerFaceColorBack;
in vec4 vertexPerFaceColorFront;
#else
in vec4 vertexColor;
#endif

#ifndef EMISSIVE
in vec4 lightMapColor;
#endif

#ifndef NO_OVERLAY
in vec4 overlayColor;
#endif

in vec2 texCoord0;

out vec4 fragColor;

#ifdef MAYBE_PLAYERDISP
in vec2 texCoord1;
in float part;

#define FADERANGE 12.0
#define FADEBIAS 8.0
#define MINALPHA 0.25

const mat4 bayer4 = mat4( 0.0 / 16.0,  8.0 / 16.0,  2.0 / 16.0, 10.0 / 16.0,
12.0 / 16.0,  4.0 / 16.0, 14.0 / 16.0,  6.0 / 16.0,
3.0 / 16.0, 11.0 / 16.0,  1.0 / 16.0,  9.0 / 16.0,
15.0 / 16.0,  7.0 / 16.0, 13.0 / 16.0,  5.0 / 16.0);

#endif

void main() {
    vec4 color = texture(Sampler0, texCoord0);

int nbMark = int(color.a * 255.0 + 0.5);
if (nbMark >= 249 && nbMark <= 254) {
    vec4 fx = nb_vfx(nbMark, color.rgb);
    if (fx.a < 0.04) {
        discard;
    }
    fragColor = apply_fog(fx, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
    return;
}
#ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
#endif

#ifdef PER_FACE_LIGHTING
    vec4 faceVertexColor = gl_FrontFacing ? vertexPerFaceColorFront : vertexPerFaceColorBack;
#else
    vec4 faceVertexColor = vertexColor;
#endif

#ifdef DISSOLVE
    if (faceVertexColor.a < texture(DissolveMaskSampler, texCoord0).a) {
        discard;
    }
    // The dissolve effect entirely replaces translucency
    faceVertexColor.a = 1.0;
#endif

    color *= faceVertexColor * ColorModulator;
#ifndef NO_OVERLAY
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
#endif
#ifndef EMISSIVE
    color *= lightMapColor;
#endif

    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);

    #ifdef MAYBE_PLAYERDISP
    if (part > 1.0 - 10e-6 && fragColor.a < 1.0) {
        fragColor.a = max(fragColor.a, MINALPHA);

        vec3 underCol = texture(Sampler0, texCoord1).rgb;
        vec3 trueMix = mix(underCol, fragColor.rgb, fragColor.a);
        float fade = mix(fragColor.a, 1.0, clamp((cylindricalVertexDistance - FADEBIAS) / (FADERANGE - FADEBIAS), 0.0, 1.0));

        fragColor = vec4((trueMix - (1 - fade) * underCol) / fade,  fade);
        if (fragColor.a < bayer4[int(gl_FragCoord.x) % 4][int(gl_FragCoord.y) % 4] + (0.5 / 16.0)) {
            discard;
        }
        else {
            fragColor.a = 1.0;
        }
    }
    #endif
}
